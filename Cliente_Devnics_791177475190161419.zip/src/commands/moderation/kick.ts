import { Command, ChatInputCommand } from '@sapphire/framework';
import { ApplyOptions } from '@sapphire/decorators';
import { ActionRowBuilder, ButtonBuilder, ButtonStyle, Colors, EmbedBuilder, GuildMember } from 'discord.js';
import users from '../../lib/models/users';
import DJS from 'discord.js';

@ApplyOptions<Command.Options>({
  name: 'kick',
  description: 'Kick an user',
})
export class TicketsCommand extends Command {
  public constructor(context: Command.Context, options: Command.Options) {
    super(context, {
      ...options,
    });
  }

  public override registerApplicationCommands(
    registry: ChatInputCommand.Registry
  ) {
    registry.registerChatInputCommand(
      (builder) =>
        builder
          .setName(this.name)
          .setDescription(this.description)
          .addUserOption((option) =>
            option
              .setName('user')
              .setDescription('User to kick')
              .setRequired(true)
          )
          .addStringOption((option) =>
            option
              .setName('reason')
              .setDescription('Reason of the kick')
              .setRequired(true)
          ),
      {
        guildIds: [process.env.GUILD_ID!],
      }
    );
  }

  public async chatInputRun(interaction: Command.ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true }).catch(() => {});

    // @ts-ignore
    if (!interaction.member.permissions.has("Administrator")) {
      const embed = new DJS.EmbedBuilder()
      .setAuthor({
          name: interaction.client.user!.username,
          iconURL: interaction.client.user!.displayAvatarURL(),
      })
      .setColor(DJS.Colors.Red)
      .setDescription(`You do not have permission to use this command`)
      .setTimestamp()
      
      return interaction.followUp({ embeds: [embed] })
  }
    let member = interaction.options.getMember('user')! as GuildMember;
    let reason = interaction.options.getString('reason')!;

    if (
      member.roles.highest.position >=
      (interaction.member! as GuildMember).roles.highest.position
    )
      return interaction.editReply(
        'You cannot kick a user with a hierarchy greater than or equal to yours'
      );
    if (
      member.roles.highest.position >=
        (
          interaction.guild!.members.cache.get(
            this.container.client.user!.id
          ) as GuildMember
        ).roles.highest.position ||
      !member.manageable
    )
      return interaction.editReply("I can't kick that member");

      let embed = new EmbedBuilder()
      .setAuthor({
        name: interaction.client.user!.username,
        iconURL: interaction.client.user!.displayAvatarURL(),
      })
      .setColor(Colors.Yellow)
      .setTitle('Please Confirm your action')
      .setDescription(
        `Are you sure you want to kick ${member.user.tag}?\nReason: ${reason}\nYou can't undo this action`
      )
      .setTimestamp();

      const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId('kick')
          .setLabel('Kick')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('cancel')
          .setLabel('Cancel')
          .setStyle(ButtonStyle.Primary)
      );

      const msg = await interaction.editReply({
        embeds: [embed],
        components: [row],
      });

      const filter = (i: any) => i.user.id === interaction.user.id;

      const collector = msg.createMessageComponentCollector({
        filter,
        time: 30000,
      });

      collector.on('collect', async (i) => {
        if (i.customId === 'kick') {
          await member.kick(reason);
          await i.update({
            embeds: [
              new EmbedBuilder()
                .setAuthor({
                  name: interaction.client.user!.username,
                  iconURL: interaction.client.user!.displayAvatarURL(),
                })
                .setColor(Colors.Yellow)
                .setDescription(
                  `${member.user.tag} has been kicked by ${interaction.user.tag}`
                )
                .setTimestamp(),
            ],
            components: [],
          });

          const data = await users.findOne({
            userId: member.id,
          });
  
          if (!data) {
            await users.create({
              userId: member.id,
              moderations: [
                {
                  guildId: interaction.guildId,
                  memberId: member.id,
                  reason: reason || 'Unspecified',
                  moderatorId: interaction.user.id,
                  timestamp: Date.now(),
                  type: 'Kick',
                },
              ],
            });
          } else {
            await users.updateOne(
              {
                userId: member.id,
              },
              {
                $push: {
                  moderations: {
                    guildId: interaction.guildId,
                    memberId: member.id,
                    reason: reason || 'Unspecified',
                    moderatorId: interaction.user.id,
                    timestamp: Date.now(),
                    type: 'Kick',
                  },
                },
              }
            );
          }
        } else {
          await i.update({
            embeds: [
              new EmbedBuilder()
                .setAuthor({
                  name: interaction.client.user!.username,
                  iconURL: interaction.client.user!.displayAvatarURL(),
                })
                .setColor(Colors.Yellow)
                .setDescription(
                  `${member.user.tag} has not been kicked by ${interaction.user.tag}`
                )
                .setTimestamp(),
            ],
            components: [],
          });
        }
      });
    }
  }
