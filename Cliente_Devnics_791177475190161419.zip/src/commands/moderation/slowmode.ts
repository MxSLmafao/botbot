import { Command, ChatInputCommand } from '@sapphire/framework';
import { ApplyOptions } from '@sapphire/decorators';
import { Colors, EmbedBuilder, TextChannel } from 'discord.js';
import DJS from 'discord.js';

@ApplyOptions<Command.Options>({
  name: 'slowmode',
  description: 'Set channel slowmode',
})
export class TicketsCommand extends Command {
  public constructor(context: Command.Context, options: Command.Options) {
    super(context, {
      ...options,
    });
  }

  public override registerApplicationCommands(
    registry: ChatInputCommand.Registry
  ) {
    registry.registerChatInputCommand(
      (builder) =>
        builder
          .setName(this.name)
          .setDescription(this.description)
          .addIntegerOption((option) =>
            option
              .setName('amount')
              .setDescription('Amount of slowmode in seconds')
              .setRequired(true)
              .setMinValue(0)
          ),
      {
        guildIds: [process.env.GUILD_ID!],
      }
    );
  }

  public async chatInputRun(interaction: Command.ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true }).catch(() => {});

     // @ts-ignore
     if (!interaction.member.permissions.has("Administrator")) {
      const embed = new DJS.EmbedBuilder()
      .setAuthor({
          name: interaction.client.user!.username,
          iconURL: interaction.client.user!.displayAvatarURL(),
      })
      .setColor(DJS.Colors.Red)
      .setDescription(`You do not have permission to use this command`)
      .setTimestamp()
      
      return interaction.followUp({ embeds: [embed] })
  }
  
    if (!interaction.channel?.isTextBased()) return;

    const amount = interaction.options.getInteger('amount')!;
    if (interaction.memberPermissions!.has('ManageMessages'))
      if (isNaN(amount))
        return interaction.reply("It doesn't seem to be valid number");

    (interaction.channel as TextChannel).setRateLimitPerUser(amount);
    if (amount > 1) {
      const embed = new EmbedBuilder()
      .setAuthor({
        name: interaction.client.user!.username,
        iconURL: interaction.client.user!.displayAvatarURL(),
      })
      .setDescription(`Slowmode is now ${amount} seconds`)
      .setColor(Colors.Green)
      .setTimestamp();

      interaction.editReply({ embeds: [embed] })
      return;
    } else {
      const embed = new EmbedBuilder()
      .setAuthor({
        name: interaction.client.user!.username,
        iconURL: interaction.client.user!.displayAvatarURL(),
      })
      .setDescription(`Slowmode is now ${amount} seconds`)
      .setColor(Colors.Green)
      .setTimestamp();

      interaction.editReply({ embeds: [embed] })
      return;
    }
  }
}
