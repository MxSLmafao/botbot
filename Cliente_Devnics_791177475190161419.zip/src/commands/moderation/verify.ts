import { Command, ChatInputCommand } from '@sapphire/framework';
import { ApplyOptions } from '@sapphire/decorators';
import {
    EmbedBuilder,
    ApplicationCommandOptionType,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    Colors
  } from 'discord.js';

@ApplyOptions<Command.Options>({
    name: 'verify',
    description: 'Send the panel to verify'
})

export class VerifyCommand extends Command {
    public constructor(context: Command.Context, options: Command.Options) {
        super(context, {
          ...options,
        });
      }

      public override registerApplicationCommands(
        registry: ChatInputCommand.Registry
        ) {
            registry.registerChatInputCommand(
                (builder) =>
                  builder
                    .setName(this.name)
                    .setDescription(this.description)
                    .addChannelOption((option) =>
                        option
                            .setName('channel')
                            .setDescription('The channel to send the panel')
                            .setRequired(true)
                        ),
                {
                  guildIds: [process.env.GUILD_ID!],
                }
              );
            }

            public async chatInputRun(interaction: Command.ChatInputCommandInteraction) {

                if (!interaction.memberPermissions.has('Administrator'))
                return interaction.followUp({
                  content: 'Necesitas permisos de administrador.',
                  ephemeral: true,
                });

                const channel = interaction.options.getChannel('channel', true);

            const row = new ActionRowBuilder<ButtonBuilder>().setComponents(

            new ButtonBuilder()
            .setCustomId("verificaus")
            .setEmoji("✔️")
            .setLabel("Verify")
            .setStyle(ButtonStyle.Success)
          )

          const embed = new EmbedBuilder()
            .setTitle("Verificación System")
            .setDescription("Click the button to verify")
            .setColor(Colors.Aqua)
            
            
            // @ts-ignore
            channel.send({
                embeds: [embed],
                components: [row]
            })
            interaction.reply({
                content: `The panel has been sent to ${channel}`,
                ephemeral: true
            })
            }
}