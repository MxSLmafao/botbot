import { Command, ChatInputCommand } from '@sapphire/framework';
import { ApplyOptions } from '@sapphire/decorators';
import { Colors, EmbedBuilder, GuildMember, GuildMemberRoleManager } from 'discord.js';
import users from '../../lib/models/users';
import DJS from 'discord.js';
// @ts-ignore
import Generator from 'id-generator';
const g = new Generator();

@ApplyOptions<Command.Options>({
  name: 'warn',
  description: 'Warn an user',
})
export class TicketsCommand extends Command {
  public constructor(context: Command.Context, options: Command.Options) {
    super(context, {
      ...options,
    });
  }

  public override registerApplicationCommands(
    registry: ChatInputCommand.Registry
  ) {
    registry.registerChatInputCommand(
      (builder) =>
        builder
          .setName(this.name)
          .setDescription(this.description)
          .addUserOption((option) =>
            option.setName('user').setDescription('The user').setRequired(true)
          )
          .addStringOption((option) =>
            option
              .setName('reason')
              .setDescription('Reason of the warning')
              .setRequired(true)
          ),
      {
        guildIds: [process.env.GUILD_ID!],
      }
    );
  }

  public async chatInputRun(interaction: Command.ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true }).catch(() => {});

     // @ts-ignore
     if (!interaction.member.permissions.has("Administrator")) {
      const embed = new DJS.EmbedBuilder()
      .setAuthor({
          name: interaction.client.user!.username,
          iconURL: interaction.client.user!.displayAvatarURL(),
      })
      .setColor(DJS.Colors.Red)
      .setDescription(`You do not have permission to use this command`)
      .setTimestamp()
      
      return interaction.followUp({ embeds: [embed] })
  }
    try {
      const { options, guild } = interaction;
      
      const user = options.getUser('user')!;
      const reason = options.getString('reason');
      const member = guild!.members.cache.get(user.id) as GuildMember;

      if (user.id == this.container.client.user!.id)
        return interaction.followUp({
          content: "You can't warn me",
        });
      if (user.id === interaction.user.id)
        return interaction.followUp({
          content: "You can't warn yourself",
        });
      if (user.id == guild!.ownerId)
        return interaction.followUp({
          content: "You can't warn the server's owner",
        });
      if (
        member?.roles.highest.position >=
          (interaction.member!.roles as GuildMemberRoleManager).highest
            .position &&
        member.id !== guild!.ownerId
      )
        return interaction.followUp({
          content: `You can't warn a member with a higher or equal role than yours`,
        });

      let toBan = false;
      const data = await users.findOne({ userId: user.id });
      if (!data) {
        await users.create({
          userId: user.id,
          moderations: [
            {
              id: g.newId(),
              guildId: guild!.id,
              memberId: user.id,
              moderatorId: interaction.user.id,
              reason: reason ?? 'Unspecified',
              timestamp: Date.now(),
              type: 'Warning',
            },
          ],
        });
      } else {
        const bans = data.moderations.filter((d) => d.type === 'Ban');
        if (bans.length! > 0) {
          const lastBan = bans[bans.length - 1];
          const banIndex = data.moderations.indexOf(lastBan);
          const dt = data.moderations.slice(banIndex, data.moderations.length);
          const warnings = dt.filter((d) => d.type === 'Warning');
          if (warnings.length >= 2) toBan = true;
        } else {
          const dt = data.moderations.slice(0, data.moderations.length);
          const warnings = dt.filter((d) => d.type === 'Warning');
          if (warnings.length >= 2) toBan = true;
        }
          

          await users.updateOne(
            {
              userId: user.id,
            },
            {
              $push: {
                moderations: {
                  id: g.newId(),
                  guildId: guild!.id,
                  memberId: user.id,
                  moderatorId: interaction.user.id,
                  reason: reason ?? 'Unspecified',
                  timestamp: Date.now(),
                  type: 'Warning',
                },
              },
            }
          );
          user
          .send({
            content: `You have been warned in **${
              guild!.name
            }** with the reason: **${reason ? reason : 'No proporcionada'}**`,
          })
          .catch(() => {
            if (interaction.channel!.isTextBased())
              interaction.channel.send({
                content: 'User got DMs closed',
              });
          });

          const embed = new EmbedBuilder()
            .setAuthor({
              name: interaction.client.user!.username,
              iconURL: interaction.client.user!.displayAvatarURL(),
            })
            .setTitle(`Warned ${user.username}`)
            .setDescription(
              `${user} has been warned` +
                `${reason ? ` with the reason: \`${reason}\`` : ''}`
            )
            .setColor(Colors.Green)
            .setTimestamp();

        return interaction
          .followUp({
            embeds: [embed],
          }).then(async () => {
            if (toBan) {
              await member.ban({ reason: '3 Warnings' });
              await users.updateOne(
                {
                  userId: member.id,
                },
                {
                  $push: {
                    moderations: {
                      guildId: interaction.guildId,
                      memberId: member.id,
                      reason: '3 warnings from last ban',
                      moderatorId: this.container.client.user!.id,
                      timestamp: Date.now(),
                      type: 'Ban',
                    },
                  },
                }
              );
            }
          });
      }
    } catch (err) {
      return console.error(err);
    }
  }
}
