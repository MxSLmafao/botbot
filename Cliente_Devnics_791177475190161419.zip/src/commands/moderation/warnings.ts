import { Command, ChatInputCommand } from '@sapphire/framework';
import { ApplyOptions } from '@sapphire/decorators';
import { Colors, EmbedBuilder, GuildMember } from 'discord.js';
import moment from 'moment';
import users from '../../lib/models/users';
import DJS from 'discord.js';

@ApplyOptions<Command.Options>({
  name: 'warnings',
  description: "List user's warnings",
})
export class TicketsCommand extends Command {
  public constructor(context: Command.Context, options: Command.Options) {
    super(context, {
      ...options,
    });
  }

  public override registerApplicationCommands(
    registry: ChatInputCommand.Registry
  ) {
    registry.registerChatInputCommand(
      (builder) =>
        builder
          .setName(this.name)
          .setDescription(this.description)
          .addUserOption((option) =>
            option.setName('user').setDescription('The user')
          ),
      {
        guildIds: [process.env.GUILD_ID!],
      }
    );
  }

  public async chatInputRun(interaction: Command.ChatInputCommandInteraction<'cached'>) {
    await interaction.deferReply({ ephemeral: true }).catch(() => {});

     // @ts-ignore
     if (!interaction.member.permissions.has("Administrator")) {
      const embed = new DJS.EmbedBuilder()
      .setAuthor({
          name: interaction.client.user!.username,
          iconURL: interaction.client.user!.displayAvatarURL(),
      })
      .setColor(DJS.Colors.Red)
      .setDescription(`You do not have permission to use this command`)
      .setTimestamp()
      
      return interaction.followUp({ embeds: [embed] })
  }
  
    try {
      const { options, guild } = interaction;

      const member =
        (options.getMember('user')! as GuildMember) || interaction.member;

      const data = await users.findOne({
        userId: member.id,
      });

      const userWarns = data?.moderations?.length
        ? data.moderations.filter((d) => d.type === 'Warning')
        : [];

        const nowarns = new EmbedBuilder()
        .setAuthor({
          name: interaction.client.user!.username,
          iconURL: interaction.client.user!.displayAvatarURL(),
        })
        .setTitle(`Warns from ${member.user.username}`)
        .setDescription(
          `No warnings`
        )
        .setColor(Colors.Yellow)
        .setTimestamp();

      if (!userWarns?.length)
        return interaction.followUp({
          embeds: [nowarns],
        });

      const embedDescription = userWarns
        .map((warn) => {
          const moderator = guild!.members.cache.get(warn.moderatorId);

          return [
            `> Moderator: ${
              moderator || `Moderator left, ID: ${warn.moderatorId}`
            }`,
            `> Date: ${moment(warn.timestamp).format('MMMM Do YYYY')}`,
            `> Reason: ${warn.reason}`,
          ].join('\n');
        })
        .join('\n\n');

      const embed = new EmbedBuilder()
        .setAuthor({
          name: interaction.client.user!.username,
          iconURL: interaction.client.user!.displayAvatarURL(),
        })
        .setTitle(`Warns from ${member.user.username}`)
        .setDescription(embedDescription)
        .setThumbnail(member.user.displayAvatarURL())
        .setColor(Colors.Yellow)
        .setTimestamp();

      return interaction.followUp({ embeds: [embed] });
    } catch (err) {
      return console.error(err);
    }
  }
}
