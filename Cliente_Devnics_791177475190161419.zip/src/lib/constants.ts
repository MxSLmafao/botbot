import { join } from 'path';

export const rootDir = join(__dirname, '..', '..');
