import { model, Schema, Types } from 'mongoose';

const requiredString = {
  type: String,
  required: true,
};

interface Moderation {
  id: string;
  guildId: string;
  memberId: string;
  moderatorId: string;
  reason: string;
  timestamp: number;
  type: 'Warning' | 'Ban' | 'Kick' | 'Mute';
}

interface Users {
  userId: string;
  moderations: Types.Array<Moderation>;
}

export default model<Users>(
  'warnings',
  new Schema({
    userId: requiredString,
    moderations: Array,
  })
);
