import crypto from 'crypto';

export function generateId(opts: IDGeneratorOptions = {}) {
	const { length, idArray } = { length: 8, idArray: [], ...opts };

	let id = crypto.randomBytes(length).toString('hex');
	while (idArray.includes(id)) {
		id = crypto.randomBytes(length).toString('hex');
	}

	return id.slice(0, length);
}

interface IDGeneratorOptions {
	length?: number;
	idArray?: string[];
}